#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


// define image size 512*512

// you can change it to other size

#define Size 256
#define Bits 256

// to find Fmax & Fmin
int Fmax(unsigned char inputG[Size][Size])
{
		int x,y,max=-1;
		for(x=0;x<Size;x++)
		{
			for(y=0;y<Size;y++)
			{
				if(inputG[x][y]>=max)
					max=inputG[x][y];
			}
		}
return max;
}
int Fmin(unsigned char inputG[Size][Size])
{
		int x,y,min=266;
		for(x=0;x<Size;x++)
		{
			for(y=0;y<Size;y++)
			{
				if(inputG[x][y]<=min)
					min=inputG[x][y];
			}
		}
return min;
}

void Linear_scaling_clipping(unsigned char Imagedata[Size][Size])
{
    int x,y,input_min,input_max;
    double slope;
    
    input_max=Fmax(Imagedata);
	input_min=Fmin(Imagedata);
	slope=(double)((Size-1)-0)/(input_max-input_min);
	for(x=0;x<Size;x++)
	{
			for(y=0;y<Size;y++)
			{
				 Imagedata[x][y]=0+(int)(slope*(Imagedata[x][y]-input_min));
			}
	}
return ;    
}

void Histogram_equalization(unsigned char Imagedata[Size][Size])
{
    int p,x,y;
    int index;
    int x_axis[Size][Size],y_axis[Size][Size];
    
	for(index=p=0;p<Bits;p++)
	{
		for(x=0;x<Size;x++)
		{
				for(y=0;y<Size;y++)
				{
					 if(Imagedata[x][y]==p)
					 {
							x_axis[(int)index/Bits][index%Bits]=x;
							y_axis[(int)index/Bits][index%Bits]=y;

					 		index++;
					 }
				}
		}
	}
	for(x=0;x<Size;x++)
	{
		for(y=0;y<Size;y++)
		{
			if(Imagedata[x_axis[x][y]][y_axis[x][y]]!=x)
				Imagedata[x_axis[x][y]][y_axis[x][y]]=x;
		}
	}
	
return ;	
}

void Quantize_five_levels(unsigned char Imagedata[Size][Size])
{
    int x,y;
    int one_pel;
    for(x=0;x<Size;x++)
	{
		for(one_pel=y=0;y<Size;y++)
		{
			if((one_pel=(int)(Imagedata[x][y]/64))==0)
				Imagedata[x][y]=0;
			else if((one_pel>=1)&&(one_pel<2))
			    Imagedata[x][y]=64;
			else if((one_pel>=2)&&(one_pel<3))
				Imagedata[x][y]=128;
			else if((one_pel>=3)&&(one_pel<4))
				Imagedata[x][y]=192;
			else if((one_pel>=4)&&(one_pel<5))
				Imagedata[x][y]=255;
		}
	}
return ;
}

void plot_Histogram(char outputname[],unsigned char Imagedata[Size][Size])
{
    FILE *file;
    int x,y,freq[Bits]={0};
    
    if (!(file=fopen(outputname,"w")))
	{
		printf("Cannot open file!\n");
		exit(1);
	}
    
    for(x=0;x<Size;x++)
    {
        for(y=0;y<Size;y++)
        {
            freq[Imagedata[x][y]]++;
        }
    }
    for(x=0;x<Bits;x++)
    {
        fprintf(file,"Bit Value:%3d. Number of Bits:%3d\n",x,freq[x]);
        for(y=0;y<freq[x];y++)
            fprintf(file,"*");
        fprintf(file,"\n");    
    }
    fclose(file);
return ;
}

int main(void)

{

	// file pointer

	FILE *file;

	// image data array

	unsigned char Imagedata[Size][Size];

    //Paramiters
    unsigned char ImageC[Size][Size];
    unsigned char ImageE[Size][Size];
    unsigned char ImageQ[Size][Size];
    int x,y;
	// read image "lena.raw" into image data matrix

	if (!(file=fopen("sample.raw","rb")))

	{

		printf("Cannot open file!\n");

		exit(1);

	}

	fread(Imagedata, sizeof(unsigned char), Size*Size, file);

	fclose(file);



	// do some image processing task...
    memcpy( ImageC ,Imagedata, sizeof(char)*Size*Size );
    memcpy( ImageE ,Imagedata, sizeof(char)*Size*Size );
    
    Linear_scaling_clipping(ImageC);
    Histogram_equalization(ImageE);
    
    memcpy( ImageQ ,ImageE, sizeof(char)*Size*Size );
    
    Quantize_five_levels(ImageQ);
    
    plot_Histogram("His_E.txt",ImageE);
    plot_Histogram("His_C.txt",ImageC);
    plot_Histogram("His_I.txt",Imagedata);
    plot_Histogram("His_Q.txt",ImageQ);
	
    // write image data to "output.raw"

	if (!(file=fopen("output.raw","wb")))

	{

		printf("Cannot open file!\n");

		exit(1);

	}
    
    for(x=0;x<Size;x++){
	   fwrite(Imagedata[x], sizeof(unsigned char), Size, file);
	   fwrite(ImageC[x], sizeof(unsigned char), Size, file);
    }
    for(x=0;x<Size;x++){
	   fwrite(ImageE[x], sizeof(unsigned char), Size, file);
	   fwrite(ImageQ[x], sizeof(unsigned char), Size, file);
    }
	fclose(file);
	exit(0);
}
